﻿# 所有BI项目

./DBbase  数据库基础方法封装 <br>
./modelapi 模型接口<br>
./Webserver<br>
./auto_batch 自动跑批相关脚本和crontab配置<br>
./Shield 稳定性守护


###### 项目文件:一般包含控制台console、实验experiment(win实验和画图)，其他文件由控制台调用:

 ./predict : 预测 <br>
 ./Profile_upl : 画像<br>

# 参考

* [Flask中文指南](http://docs.jinkan.org/docs/flask/).
* [Seaborn-02-颜色板控制](http://www.jianshu.com/p/25bfbca6fc0b).
* [Seaborn-03-数据分布图](http://www.jianshu.com/p/efc9010c9940).
* [DataFrame基本操作](http://www.jianshu.com/p/682c24aef525).
* [先收藏一个再说](http://www.jianshu.com/p/9c1d5eaf1c0c).



* [flask~doc (ง •̀灬•́)ง ](http://docs.jinkan.org/docs/flask/quickstart.html#a-minimal-application).