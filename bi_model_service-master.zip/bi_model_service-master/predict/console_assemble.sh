#!/usr/bin/env bash
python3 ../Shield/general_shield.py './console.py' 'mode=sf_log&lourl=/tmp/predict_log&interval=666'